# EJERCICIO DE CREACIÓN DE INSTANCIAS

Ángela Orcera Ruiz (1º DAW - `Entornos de Desarrollo`)

## 1) *START LAB*

He iniciado el *laboratorio de AWS*, obviamente dándole al **"Start lab"**, estaba el circulito al lado de aws rojo porque estaba como aún no iniciado.

<img width="1767" height="795" alt="start lab" src="https://github.com/user-attachments/assets/bf3390cc-33ca-4555-bff6-526337e8b691" />


Aquí el circulito pasó a estar verde y ya se ***inició el laboratorio***.

<img width="1327" height="797" alt="AWS LAB INICIADO" src="https://github.com/user-attachments/assets/c671dfc4-79e6-4061-a392-85c60c1256f4" />


---


## 2) *Creando las instancias*

Le di click en el AWS al lado del circulito verde.

He comenzado buscando en el buscador EC2, para así buscar las instancias y ver cuales lanzo

<img width="1497" height="752" alt="BUSCAR EC2" src="https://github.com/user-attachments/assets/32caf0a7-fee1-418c-b94c-70a253813d10" />


En la siguiente captura se ve la lista de las instancias que le podemos dar uso, yo he usado de la capa gratuita y he lanzado la de **Amazon** **Linux**, **Ubuntu** y **Debian**.

<img width="1278" height="727" alt="BUSCANDO INSTANCIAS" src="https://github.com/user-attachments/assets/217d5d10-71da-4d8b-95f0-67e832dedab9" />


Cuando eliges las instancias a la hora de instalarlas , he dejado las configuraciones por defecto como así también las configuraciones de almacenamiento.

A la hora de escoger las claves se pueden generar en formato pen si lo hace uno/a mismo/a pero he optado por usar la de vockey,porque si Susana,soy muy despistada...

<img width="1257" height="343" alt="CLAVE INSTANCIAS" src="https://github.com/user-attachments/assets/55eecbde-ad74-4809-a75e-d836b430b446" />


---


## 3) *Lanzando las instancias*

Cuando ya está todo configurado, se le da click al botón de **"lanzar instancia"** y ya se inicia todo (o casi todo).

Sale esto por pantalla:

<img width="1752" height="738" alt="HACIENDO INSTANCIA" src="https://github.com/user-attachments/assets/3be96acb-cd16-4c7d-b8eb-23abb064b560" />


Y una vez finalizada esa barrilla ya por fin tenemos nuestra instancia o en este caso instancias lanzadas.

<img width="1360" height="428" alt="INSTANCIA LANZADA" src="https://github.com/user-attachments/assets/92ce0026-c2f3-4d6f-9e0c-f79abab1bc99" />


> *Para acceder debe estar abierta*

He hecho lo mismo (osease, el mismo procedimiento y dejando las configuraciones por defecto) con las instancias de Ubunty y Debian.

<img width="1078" height="455" alt="LANZAR UBUNTU" src="https://github.com/user-attachments/assets/02f86a5a-f30b-40ba-9aa9-b59103c31fbb" />


Aquí en esta captura aparecen las instancias que se han creado:

<img width="1557" height="322" alt="INSTANCIAS CREADAS" src="https://github.com/user-attachments/assets/84d8876d-c0c3-48b0-ac9b-5e57f0d9702e" />


> He tenido un lapsus y lo de fedora es el linux de Amazon...

A continuación, cuando das a conectar a cualquiera de las instancias ya aparece lista para trabajar en estas, he puesto los ejemplos de Amazon Linux y Ubuntu:

<img width="1878" height="731" alt="INSTANCIA AMAZON" src="https://github.com/user-attachments/assets/e53a43bd-14a8-4c9d-a165-f714e24e1364" />
> La instancia de Amazon linux

<img width="1856" height="746" alt="INSTANCIA UBUNTU" src="https://github.com/user-attachments/assets/8faa8987-a483-437a-898f-d14c3adb62f1" />

> Esta es la de ubuntu

---

Esto sería todo, ahora lo único que queda es darle a **"end lab"** (y no al reset, que eso ya es peligro total).




